package ProjectTestNG;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class TrydemoLogin {@BeforeTest
	  public void beforeTest() throws InterruptedException 
{
	System.setProperty("webdriver.chrome.driver", "C:\\Automation Folder\\Browser extension\\chromedriver.exe");
    ChromeDriver driver=new ChromeDriver();
    driver.manage().window().maximize();
	driver.manage().deleteAllCookies();
	Thread.sleep(2000);
	
	  }

	
  @Test(description = "parallel testing")
  public void Trydemologin() throws InterruptedException 
  {
	ChromeDriver chromeDriver = new ChromeDriver();
			//URL
			chromeDriver.get("https://www.arubanetworks.com/en-in");
			chromeDriver.manage().window().maximize();
			chromeDriver.manage().deleteAllCookies();
			Thread.sleep(2000);
			
			//Try demo
			chromeDriver.findElement(By.xpath("//*[@id=\"menu-main-navigation-english-india\"]/li[7]/a")).click();
			Thread.sleep(2000);
			
			//aruba networking central 
			chromeDriver.findElement(By.xpath("//*[@id=\"content\"]/section[2]/div/div/div[1]/div[2]/div/h3/a")).sendKeys(Keys.ENTER);
			Thread.sleep(2000);
			
			// Scrolling down 
			JavascriptExecutor js=(JavascriptExecutor)chromeDriver;
			 
			 js.executeScript("window.scrollBy(0,200)");
			 Thread.sleep(2000);
	  
  }
  
  @AfterTest
  public void afterTest() 
  {
	  ChromeDriver chromeDriver = new ChromeDriver();
	  chromeDriver.close();
  }

}
