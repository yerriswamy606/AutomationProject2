package ProjectFunctionalities;

import java.util.Scanner;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class CrossBrowserTesting {

	public static void main(String[] args) 
	{
		Scanner s = new Scanner(System.in);
		  System.out.println("Enter 1 for GoogleChrome.\nEnter 2 for MSEdge.\nEnter 3 for MozillaFirefox.");
		  int input=s.nextInt();
		  
		  WebDriver driver = null;
		  
		  switch(input)
		  {
		  case 1:
			  System.out.println("***GoogleChrome***");
			  System.setProperty("webdriver.chrome.driver", "C:\\Automation Folder\\Browser extension\\chromedriver.exe");
			  driver=new ChromeDriver();
			  break;
			
		  case 2:
			  System.out.println("***MSEdge***");
			  System.setProperty("webdriver.edge.driver", "C:\\Automation Folder\\Browser extension\\msedgedriver.exe");
			  driver=new EdgeDriver();
			  break;
		  case 3:  
			  System.out.println("***MozillaFirefox***");
			  System.setProperty("webdriver.gecko.driver", "C:\\Automation Folder\\Browser extension\\geckodriver.exe");
			  driver=new FirefoxDriver();
			  break;
		   
			 default: System.out.println("Invalid input");

	}
		    driver.get("https://common.cloud.hpe.com/home");
			driver.manage().window().maximize();
			driver.manage().deleteAllCookies();

	}
}
              
