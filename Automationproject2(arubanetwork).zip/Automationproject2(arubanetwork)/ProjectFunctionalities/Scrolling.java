package ProjectFunctionalities;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Scrolling {

	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver","C:\\Automation Folder\\Browser extension\\chromedriver.exe");
		//Step 2: Update Webdriver + Browser
		  WebDriver driver=new ChromeDriver();
		//URL
		driver.get("https://www.arubanetworks.com/en-in");
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();	
		Thread.sleep(2000);
		
		JavascriptExecutor js=(JavascriptExecutor)driver;
		 
		 js.executeScript("window.scrollBy(0,1000)");
		 Thread.sleep(2000);

		 js.executeScript("window.scrollBy(0,1000)");
		 Thread.sleep(2000);

		 js.executeScript("window.scrollBy(0,1000)");
		 Thread.sleep(2000);

		 js.executeScript("window.scrollBy(0,1000)");
		 Thread.sleep(2000);
		 
		 js.executeScript("window.scrollBy(0,1000)");
		 Thread.sleep(2000);
		 
		 js.executeScript("window.scrollBy(0,1000)");
		 Thread.sleep(2000);
		 
		//4th Way: Up
		 driver.findElement(By.xpath("//*[@id=\"main\"]/div[1]")).click();
		 
		 //js.executeScript("window.scrollTO(0,-document.body.scrollHeight)");
		 Thread.sleep(2000);
		 
		 
		 

	}

}
