package ProjectFunctionalities;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class URLTesting 
{

	public static void main(String[] args) 
	{
		System.setProperty("webdriver.chrome.driver","C:\\Automation Folder\\Browser extension\\chromedriver.exe");
		//Step 2: Update Webdriver + Browser
		  WebDriver driver=new ChromeDriver();
		//URL
		driver.get("https://common.cloud.hpe.com/home");
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();

	}

}
