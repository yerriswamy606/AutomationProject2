package ProjectFunctionalities;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class MouseHover {

	public static void main(String[] args) throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Automation Folder\\Browser extension\\chromedriver.exe");
		ChromeDriver driver=new ChromeDriver();
		
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		
		driver.get("https://www.arubanetworks.com/en-in");
		Thread.sleep(2000);
		
		//WebElement Products=driver.findElement(By.xpath("//*[@id=\"menu-main-navigation-english-india\"]/li[1]/a"));
		//WebElement Partner=driver.findElement(By.xpath("//*[@id=\"menu-main-navigation-english-india\"]/li[6]/a"));

		
		
		 Actions a = new Actions(driver);
		
			
			List<WebElement> Is = driver.findElements(By.xpath("//ul[@class='nav-menu']/li"));
			
			int size = Is.size();
			System.out.println("No of modules: "+size);
			
			for(int i=1;i<=size;i++)
			{
				Thread.sleep(2000);
				System.out.println(driver.findElement(By.xpath("//ul[@class='nav-menu']/li["+i+"]")).getText());
			
				a.moveToElement(driver.findElement(By.xpath("//ul[@class='nav-menu']/li["+i+"]"))).click().perform();
				

			}
			
        
         
      
	}

}
