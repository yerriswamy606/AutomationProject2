package ProjectPageFactory;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.FindBy;
import org.testng.annotations.AfterTest;

public class BaseClass 
{
  
    @FindBy(id="user-name")
	WebElement username;
	
	@FindBy(id="password")
	WebElement password;
	
	@FindBy(id="login-button")
	WebElement signinButton;
	@Test
  
  public void signin(EdgeDriver driver, String usn, String pwd) 
	{
		 username.sendKeys(usn);
		 password.sendKeys(pwd);
		 signinButton.click();
  }

}
