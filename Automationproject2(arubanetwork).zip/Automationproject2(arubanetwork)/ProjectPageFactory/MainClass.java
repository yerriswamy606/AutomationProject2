package ProjectPageFactory;

import org.testng.annotations.Test;

import org.testng.annotations.BeforeTest;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterTest;

public class MainClass {
  @Test
  
  public void login() throws InterruptedException 
  {
	  System.setProperty("webdriver.chrome.driver","C:\\Automation Folder\\Browser extension\\msedgedriver.exe");
	  EdgeDriver driver = new EdgeDriver();	
	  Thread.sleep(2000);
	  
	  driver.manage().window().maximize();
	  Thread.sleep(2000);
	  
	  driver.manage().deleteAllCookies();
	  
	  //URL
	  driver.get("https://common.cloud.hpe.com/home");
	  System.out.println("LoginPage Title: "+driver.getTitle());
	  System.out.println("LoginPage URL: "+driver.getCurrentUrl());
	  
	  //Create object PageFactory/BaseClass
	  BaseClass b=PageFactory.initElements(driver,BaseClass.class);
	  
	  //Calling method
	  b.signin(driver, "standard_user", "secret_sauce");
	  System.out.println("\nHomePage Title: "+driver.getTitle());
	  System.out.println("HomePage URL: "+driver.getCurrentUrl());
  }
 

}
