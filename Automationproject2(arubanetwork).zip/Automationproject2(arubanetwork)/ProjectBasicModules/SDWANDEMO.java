package ProjectBasicModules;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class SDWANDEMO {

	public static void main(String[] args) throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver","C:\\Automation Folder\\Browser extension\\chromedriver.exe");
		//Step 2: Update Webdriver + Browser
		  WebDriver driver=new ChromeDriver();
		//URL
		driver.get("https://www.arubanetworks.com/en-in");
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		Thread.sleep(2000);
		
		//Try demo
		driver.findElement(By.xpath("//*[@id=\"menu-main-navigation-english-india\"]/li[7]/a")).click();
		Thread.sleep(6000);
		
		JavascriptExecutor js=(JavascriptExecutor)driver;
		 
		 js.executeScript("window.scrollBy(0,500)");
		 Thread.sleep(2000);
		 
		 js.executeScript("window.scrollBy(0,500)");
		 Thread.sleep(2000);
		
		//USER Experience 
		driver.findElement(By.xpath("//*[@id=\"content\"]/section[2]/div/div/div[5]/div[2]/div/h3/a")).sendKeys(Keys.ENTER);
		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"firstName\"]")).sendKeys("shubhman");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"lastName\"]")).sendKeys("gill");
		Thread.sleep(6000);			
		
		driver.findElement(By.xpath("//*[@id=\"emailID\"]")).sendKeys("gysyece730@gmail.com");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"jobTitle\"]")).sendKeys("Tester");
		driver.findElement(By.xpath("//*[@id=\"companyID\"]")).sendKeys("biologicalprivatelimited");
		
		WebElement Yourname=driver.findElement(By.xpath("//*[@id=\"countryID\"]"));
		Select s=new Select(Yourname);
		s.selectByVisibleText("Canada");
		Thread.sleep(6000);	
			
		
		driver.findElement(By.xpath("//*[@id=\"zipPostal\"]")).sendKeys("500078");
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//*[@id=\"busPhone\"]")).sendKeys("125000781");
		Thread.sleep(2000);	
		
		driver.findElement(By.xpath("//*[@id=\"recaptcha-anchor\"]/div[1]")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//*[@id=\"elqFormSubmitBut\"]")).click();
		Thread.sleep(2000);
		
	}

}
