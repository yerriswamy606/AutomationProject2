package ProjectBasicModules;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HomePageandlogoutmodule {

	public static void main(String[] args) throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver","C:\\Automation Folder\\Browser extension\\chromedriver.exe");
		//Step 2: Update Webdriver + Browser
		  WebDriver driver=new ChromeDriver();
		//URL
		driver.get("https://common.cloud.hpe.com/home");
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		Thread.sleep(2000);
		
		 //Open application tab
		 driver.findElement(By.xpath("/html/body/div/div[1]/greenlake-header//header/div/center-nav//nav/fast-button[2]/formatted-message")).sendKeys(Keys.ENTER);;
		 Thread.sleep(3000);
		 
		 //Open Devices tab
		 
		 driver.findElement(By.xpath("/html/body/div/div[1]/greenlake-header//header/div/center-nav//nav/fast-button[3]/formatted-message")).sendKeys(Keys.ENTER);;
		 Thread.sleep(3000);
		 
		 //Open Manage button
		 driver.findElement(By.xpath("/html/body/div/div[1]/greenlake-header//header/div/center-nav//nav/fast-button[4]/formatted-message")).click();
		 Thread.sleep(3000);
		 
		 //Open Profile button
		 driver.findElement(By.xpath("/html/body/div/div[1]/greenlake-header//header/div/div[2]/user-menu//menu-button/img")).click();
		 Thread.sleep(3000);
		 
		 //LogOut Button
		 driver.findElement(By.xpath("/html/body/div/div[1]/greenlake-header//header/div/div[2]/user-menu//menu-button/div/fast-menu/fast-menu-item[4]/formatted-message")).click();
		 Thread.sleep(3000);
		 

	}

}
