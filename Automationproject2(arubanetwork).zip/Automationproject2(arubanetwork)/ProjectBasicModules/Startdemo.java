package ProjectBasicModules;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Startdemo {

	public static void main(String[] args) throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver","C:\\Automation Folder\\Browser extension\\chromedriver.exe");
		//Step 2: Update Webdriver + Browser
		  WebDriver driver=new ChromeDriver();
		//URL
		driver.get("https://www.arubanetworks.com/en-in");
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		Thread.sleep(2000);
		
		//Try demo
		driver.findElement(By.xpath("//*[@id=\"menu-main-navigation-english-india\"]/li[7]/a")).click();
		Thread.sleep(2000);
		
		//aruba networking central 
		driver.findElement(By.xpath("//*[@id=\"content\"]/section[2]/div/div/div[1]/div[2]/div/h3/a")).sendKeys(Keys.ENTER);
		Thread.sleep(2000);
		
		// Scrolling down 
		JavascriptExecutor js=(JavascriptExecutor)driver;
		 
		 js.executeScript("window.scrollBy(0,1000)");
		 Thread.sleep(2000);
		 
		//not a robot
		 driver.findElement(By.xpath("//*[@id=\"recaptcha-anchor\"]/div[1]")).click();
		 Thread.sleep(2000);
		 
		 // submit
		 driver.findElement(By.xpath("//*[@id=\"submit\"]")).click();
		 Thread.sleep(2000);


	}

}
