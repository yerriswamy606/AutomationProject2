package ProjectBasicModules;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Trydemo {

	public static void main(String[] args) throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver","C:\\Automation Folder\\Browser extension\\chromedriver.exe");
		//Step 2: Update Webdriver + Browser
		  WebDriver driver=new ChromeDriver();
		//URL
		driver.get("https://www.arubanetworks.com/en-in");
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		Thread.sleep(2000);
		
		//Try demo
		driver.findElement(By.xpath("//*[@id=\"menu-main-navigation-english-india\"]/li[7]/a")).click();
		Thread.sleep(2000);
		
		//aruba networking central 
		driver.findElement(By.xpath("//*[@id=\"content\"]/section[2]/div/div/div[1]/div[2]/div/h3/a")).sendKeys(Keys.ENTER);
		Thread.sleep(2000);
		
		// Scrolling down 
		JavascriptExecutor js=(JavascriptExecutor)driver;
		 
		 js.executeScript("window.scrollBy(0,200)");
		 Thread.sleep(2000);
		// First name 
		 driver.findElement(By.xpath("//*[@id=\"firstname\"]")).sendKeys("abhilash");
		 Thread.sleep(2000);
		 
		// Last name 
		 driver.findElement(By.xpath("//*[@id=\"lastname\"]")).sendKeys("Reddy");
		 Thread.sleep(2000);
	
		 //Email 
		 driver.findElement(By.xpath("//*[@id=\"email\"]")).sendKeys("qwerty@gmail.com");
		 Thread.sleep(2000);
		 
		 //Phone 
		 driver.findElement(By.xpath("//*[@id=\"busPhone\"]")).sendKeys("8143218768");
		 Thread.sleep(2000);
		 
		 //Title
		 driver.findElement(By.xpath(" //*[@id=\"title\"]")).sendKeys("TestEngineer");
		 Thread.sleep(2000);
		 
		 //Company
		 driver.findElement(By.xpath("//*[@id=\"company\"]")).sendKeys("BharatBiotech");
		 Thread.sleep(2000);
		 
		 //slider
		 js.executeScript("window.scrollBy(0,200)");
		 Thread.sleep(5000);
		 
		 //Select country
		 //WebElement Yourname=driver.findElement(By.id("//*[@id='country']"));
		 //Select s=new Select(Yourname);
			
		 //s.selectByVisibleText("india");
		 //Thread.sleep(5000);		 
		 	 
		 //Email
		// driver.findElement(By.xpath("//*[@id=\"gdpr-label\"]")).click();
		 //Thread.sleep(2000);
		 
		 //not a robot
		 driver.findElement(By.xpath("//*[@id=\"recaptcha-anchor\"]/div[1]")).click();
		 Thread.sleep(2000);
		 
		 //Start demo 
		 
			
		 
}

}
