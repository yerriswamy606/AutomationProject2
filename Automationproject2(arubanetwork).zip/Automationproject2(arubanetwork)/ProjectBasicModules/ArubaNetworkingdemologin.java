package ProjectBasicModules;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class ArubaNetworkingdemologin {

	public static void main(String[] args) throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver","C:\\Automation Folder\\Browser extension\\chromedriver.exe");
		//Step 2: Update Webdriver + Browser
		  WebDriver driver=new ChromeDriver();
		//URL
		driver.get("https://www.arubanetworks.com/en-in");
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		Thread.sleep(2000);
		
		//Try demo
		driver.findElement(By.xpath("//*[@id=\"menu-main-navigation-english-india\"]/li[7]/a")).click();
		Thread.sleep(6000);
		
		//USER Experience 
		driver.findElement(By.xpath("//*[@id=\"content\"]/section[2]/div/div/div[2]/div[2]/div/h3/a")).sendKeys(Keys.ENTER);
		Thread.sleep(2000);
		
		String parentWindow=driver.getWindowHandle();
		System.out.println("Parent Window ID: "+parentWindow);
		Thread.sleep(5000);
		
		//To store Child window id >> getWindowHandles()
		Set<String> childWindow=driver.getWindowHandles();
		
		//For Each >> For Collection
		for(String windowHandle:childWindow)
		{
			if(!windowHandle.equals(parentWindow))
			{
				//Switch to Child Window
				driver.switchTo().window(windowHandle);
				System.out.println("Child Window ID: "+childWindow);				
				Thread.sleep(6000);
		
		//request for demo
		driver.findElement(By.xpath("//*[@id=\"field0\"]")).sendKeys("shubhman");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"field1\"]")).sendKeys("gill");
		Thread.sleep(6000);			
		driver.findElement(By.xpath("//*[@id=\"field2\"]")).sendKeys("BiologicalElimited");
		driver.findElement(By.xpath("//*[@id=\"field3\"]")).sendKeys("gysyece730@gmail.com");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"field4\"]")).sendKeys("9182345687");
		Thread.sleep(2000);
		WebElement Yourname=driver.findElement(By.xpath("//*[@id=\"field5\"]"));
		Select s=new Select(Yourname);
		s.selectByVisibleText("Canada");
		Thread.sleep(6000);	
		
		
		WebElement Yourname1=driver.findElement(By.xpath("//*[@id=\"field6\"]"));
		Select s1=new Select(Yourname1);
		s1.selectByVisibleText("Alaska");
		Thread.sleep(6000);
		
		WebElement Yourname2=driver.findElement(By.xpath("//*[@id=\"field7\"]"));
		Select s2=new Select(Yourname2);
		s2.selectByVisibleText("Education");
		Thread.sleep(6000);	
		
		driver.findElement(By.xpath("//*[@id=\"field8\"]")).sendKeys("Two locations 2 users");
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//*[@id=\"formElement10\"]/div[2]/div/p/span/span/input")).click();
		Thread.sleep(2000);
		
		//Request a Demo
		driver.findElement(By.xpath("//*[@id=\"formElement19\"]/div[2]/div/p/input")).click();
		Thread.sleep(2000);
		
	}

}
	}
}
