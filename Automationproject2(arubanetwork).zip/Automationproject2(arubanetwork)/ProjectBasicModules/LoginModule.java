package ProjectBasicModules;

import java.util.Arrays;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoginModule {

	public static void main(String[] args) throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver","C:\\Automation Folder\\Browser extension\\chromedriver.exe");
		//Step 2: Update Webdriver + Browser
		  WebDriver driver=new ChromeDriver();
		  
		//URL
		driver.get("https://www.arubanetworks.com/en-in");
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		Thread.sleep(2000);
		
		//Login
		driver.findElement(By.xpath("//*[@id=\"menu-item-145895\"]/a")).click();
		Thread.sleep(2000);
		
		//aruba central 
		driver.findElement(By.xpath("//*[@id=\"menu-item-145895\"]/div/ul/li[1]")).click();
		Thread.sleep(2000);
		
		String parentWindow=driver.getWindowHandle();
		System.out.println("Parent Window ID: "+parentWindow);
		Thread.sleep(5000);	
		
		//To store Child window id >> getWindowHandles()
				Set<String> childWindow=driver.getWindowHandles();
				
				//For Each >> For Collection
				for(String windowHandle:childWindow)
				{
					if(!windowHandle.equals(parentWindow))
					{
						//Switch to Child Window
						driver.switchTo().window(windowHandle);
						System.out.println("Child Window ID: "+childWindow);				
						Thread.sleep(6000);
						
						ChromeOptions option =new ChromeOptions();
						option.addArguments("--disable-notifications");
						//option.setExperimentalOption("excludeSwitches",Arrays.asList("disable-popup-blocking"));
						//Task
						driver.findElement(By.xpath("//*[@id=\"idp-discovery-username\"]")).sendKeys("gysyece730@gmail.com");
						Thread.sleep(2000);
						driver.findElement(By.xpath("//*[@id=\"idp-discovery-username\"]")).sendKeys(Keys.ENTER);
						Thread.sleep(6000);			
						driver.findElement(By.xpath("//*[@id=\"okta-signin-password\"]")).sendKeys("Victory@24");
						driver.findElement(By.xpath("//*[@id=\"okta-signin-password\"]")).sendKeys(Keys.ENTER);
						Thread.sleep(2000);
						//NEXT
						driver.findElement(By.xpath("//*[@id=\"okta-signin-submit\"]")).click();
						Thread.sleep(6000);
						
				
						
						
						//remove crossbar
						// driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[3]/div/button/svg/path")).sendKeys(Keys.ENTER);
						// Thread.sleep(3000);
	
						//Open application tab
						 /*driver.findElement(By.xpath("/html/body/div/div[1]/greenlake-header//header/div/center-nav//nav/fast-button[2]/formatted-message")).sendKeys(Keys.ENTER);;
						 Thread.sleep(3000);
						 
						 //Open Devices tab
						 
						 driver.findElement(By.xpath("/html/body/div/div[1]/greenlake-header//header/div/center-nav//nav/fast-button[3]/formatted-message")).sendKeys(Keys.ENTER);;
						 Thread.sleep(3000);
						 
						 //Open Manage button
						 driver.findElement(By.xpath("/html/body/div/div[1]/greenlake-header//header/div/center-nav//nav/fast-button[4]/formatted-message")).click();
						 Thread.sleep(3000);
						 
						 //Open Profile button
						 driver.findElement(By.xpath("/html/body/div/div[1]/greenlake-header//header/div/div[2]/user-menu//menu-button/img")).click();
						 Thread.sleep(3000);*/
						 
						 //LogOut Button
						 driver.findElement(By.cssSelector("This element is in shadowDOM - .menu-button-icon"));
						 Thread.sleep(3000);
						 

						 
	}

}
}

	
	}
